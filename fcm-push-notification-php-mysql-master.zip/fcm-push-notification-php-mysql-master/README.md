# fcm-push-notification-php-mysql

Follow this tutorials: https://www.youtube.com/watch?v=gxwbP7fNOzI&list=PLCakfctNSHkGLCs9az_9PKqW1NY1C5HIU
